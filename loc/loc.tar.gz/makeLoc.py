#!/usr/bin/python
# -*- coding: utf-8 -*-

import matplotlib
import numpy
import glob
import datetime
import matplotlib.pyplot as plt
from   array             import array
from   os                import listdir
from   os.path           import basename
from   funciones         import cosSolarZenithAngle

# lista_locs = []
# lista_locs_resoluciones = []
# lista_resoluciones = []

#########################################
#########################################
#########################################

def getDate(file):

  base_file = basename(file)
  year      = base_file[4:8]
  doy       = base_file[8:11]
  hh        = base_file[12:14]
  mm        = base_file[14:16]
  ss        = base_file[16:18]

  return int(year), int(doy), int(hh), int(mm), int(ss)

#########################################
#########################################
#########################################

def getJILess(loc_lat, loc_lon, loc_res, LATdeg_vec, LONdeg_vec):
  min_lon = loc_lon - float(loc_res)
  max_lon = loc_lon + float(loc_res)
  min_lat = loc_lat - float(loc_res)
  max_lat = loc_lat + float(loc_res)

  # genero un meshgrid a partir de LonVec y LatVec
  lons2d, lats2d = numpy.meshgrid(LONdeg_vec, LATdeg_vec)
  # y luego obtengo sus coordenadas en el mapa ax

  j_less  = len(lons2d)
  j_great = 0

  i_less  = len(lats2d)
  i_great = 0

  for i in range(0,len(lons2d)):      # recorro verticalmente
    for j in range(0,len(lons2d[0])): # recorro horizontalmente
      if (lons2d[i][j] > min_lon) and\
         (lons2d[i][j] < max_lon) and\
         (lats2d[i][j] > min_lat) and\
         (lats2d[i][j] < max_lat):
        if j < j_less:
          j_less = j
        if j > j_great:
          j_great = j

        if i < i_less:
          i_less = i
        if i > i_great:
          i_great = i

  print('x,%d,%d y,%d,%d' % (j_less, j_great, i_less, i_great))
  return j_less, j_great, i_less, i_great

#########################################
#########################################
#########################################

def makeLocFile(path_base, path_out, loc_name, loc_lat, loc_lon, loc_res):

  ##############################

  # abro el archivo meta y guardo los datos
  fid = open(path_base + 'meta/' + 'T000gri.META', 'r')
  meta = numpy.fromfile(fid, dtype='float32')
  fid.close()

  # abro el archivo T000gri.LATvec y guardo los datos
  fid = open(path_base + 'meta/' + 'T000gri.LATvec', 'r')
  LATdeg_vec = numpy.fromfile(fid, dtype='float32')
  LATdeg_vec = LATdeg_vec[::-1] # invierto el arreglo porque quedaba invertido verticalmente
  fid.close()

  # abro el archivo T000gri.LONvec y guardo los datos
  fid = open(path_base + 'meta/' + 'T000gri.LONvec', 'r')
  LONdeg_vec = numpy.fromfile(fid, dtype='float32')
  fid.close()

  # obtengo del vector meta el largo y alto de elementos de los vectores y los datos
  Ci = int(meta[0])
  Cj = int(meta[1])
  Ct = Ci*Cj

  print('getJILess')
  j_less, j_great, i_less, i_great = getJILess(loc_lat, loc_lon, loc_res, LATdeg_vec, LONdeg_vec)

  ##############################

  epoch = datetime.datetime.strptime('2000 01 00 00 00', '%Y %j %H %M %S')

  path_years = path_base + 'B01-FR/'

  # listar directorio de anos
  years = sorted(listdir(path_years))

  loc_year_data = []
  loc_year_cnt  = []
  loc_year_date = []
  loc_year_meta = []

  for year in years[0:1]:

    path_fr_year = path_years + year + "/"

    files_in_year = sorted(glob.glob(path_fr_year + "*.FR"))

    for file in files_in_year: #[0:27]

      # file = abrir archivo
      fid = open(file, 'r')
      data = numpy.fromfile(fid, dtype='float32') # FR
      fid.close()

      IMG = []
      IMG = numpy.reshape(data, (Ci, Cj))

      # obtener recorte
      # IMG_small = IMG[i_less-2:i_great+2,j_less-2:j_great+2]
      IMG_small = IMG[i_less:i_great,j_less:j_great]

      mean = numpy.mean(IMG_small)
      # print(mean)

      year, doy, hh, mm, ss = getDate(file)
      cnt = numpy.size(IMG_small)

      # print("cnt: %d" % (cnt))
      # print("%d %d %d %d %d" % (year, doy, hh, mm, ss))
      # calcular MSK
      # calcular STE
      # calcular ITE


      time_data = str(year) + " " + str(doy) + " " + str(hh)  + " " + str(mm)  + " " + str(ss)
      date = datetime.datetime.strptime(time_data, '%Y %j %H %M %S')

      ite = float((date-epoch).total_seconds())/(24.0*60.0*60.0) # segundos desde el 2000-01-00:00:00 dividido total de secs en un dia
      print("ite: %f" % (ite))

      csza = cosSolarZenithAngle(loc_lat, loc_lon, date)

      if (mean>0) or (csza<=0):
        msk = 1
      else:
        msk = 0

      sat = 8

      # # hacer push de todo en loc_year_data y loc_year_meta
      loc_year_data.append(mean)
      loc_year_date.append(date)
      loc_year_cnt.append(cnt)

      loc_year_meta.append(year)
      loc_year_meta.append(doy)
      loc_year_meta.append(hh)
      loc_year_meta.append(mm)
      loc_year_meta.append(ss)
      loc_year_meta.append(msk)
      loc_year_meta.append(cnt)
      loc_year_meta.append(ite)
      loc_year_meta.append(sat)

      # for loc in lista_locs:
      #   for loc_res in lista_locs_resoluciones:
      #   # for loc_res
      # # for loc

    # for file

    plt.plot_date(loc_year_date, loc_year_data, '-', linewidth=1, alpha=0.8)
    plt.tick_params(axis='x', labelsize=13)
    plt.savefig('P02_C01x01_2000.png')

    output_file = open(path_out + 'P02_C01x01_2000_NEW.FR', 'wb')
    myarray = numpy.array(loc_year_data, dtype=numpy.float32)
    myarray.tofile(output_file)
    output_file.close()

    output_file = open(path_out + 'P02_C01x01_2000_NEW.META', 'wb')
    myarray = numpy.array(loc_year_meta, dtype=numpy.float32)
    myarray.tofile(output_file)
    output_file.close()

    plt.show()

  # for year

  # volcar archivos a disco FRs y Metas

  del loc_year_data
  del loc_year_meta
  # gc.collect()

# makeLocFile()

estaciones = [
["Les",        -31.272756, -57.89092, 0.25],\
["UY" ,        -32.5453,   -55.7287,  3],\
["La Jacinta", -31.4342,   -57.8988 , 0.015],\
]

estacion = estaciones[2]

path_base = '/sat/art-sat/ART_G015x015UY_C015x015/'
path_out  = '/sat/PRS/dev/loc/'
loc_name  = estacion[0]
loc_lat   = estacion[1]
loc_lon   = estacion[2]
loc_res   = estacion[3]

makeLocFile(path_base, path_out, loc_name, loc_lat, loc_lon, loc_res)
