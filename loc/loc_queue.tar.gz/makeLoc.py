#!/usr/bin/python3.6
# -*- coding: utf-8 -*-

import numpy
import glob
import datetime
from loc_types import *

from array           import array
from os              import listdir
from os.path         import basename
from funciones       import cosSolarZenithAngle
from multiprocessing import Queue

# lista_locs = []
# lista_locs_resoluciones = []
# lista_resoluciones = []

#########################################
#########################################
#########################################

def getDate(file):

  base_file = basename(file)
  year      = base_file[4:8]
  doy       = base_file[8:11]
  hh        = base_file[12:14]
  mm        = base_file[14:16]
  ss        = base_file[16:18]

  return int(year), int(doy), int(hh), int(mm), int(ss)

#########################################
#########################################
#########################################

def getJILess(loc_lat, loc_lon, loc_res, LATdeg_vec, LONdeg_vec):

  min_lon = loc_lon - float(loc_res)
  max_lon = loc_lon + float(loc_res)
  min_lat = loc_lat - float(loc_res)
  max_lat = loc_lat + float(loc_res)

  # print("min_lon: %f"%(min_lon))
  # print("max_lon: %f"%(max_lon))
  # print("min_lat: %f"%(min_lat))
  # print("max_lat: %f"%(max_lat))

  # genero un meshgrid a partir de LonVec y LatVec
  lons2d, lats2d = numpy.meshgrid(LONdeg_vec, LATdeg_vec)

  j_less  = len(lons2d)
  j_great = 0

  i_less  = len(lats2d)
  i_great = 0

  for i in range(0,len(lons2d)):      # recorro verticalmente
    for j in range(0,len(lons2d[0])): # recorro horizontalmente
      if (lons2d[i][j] > min_lon) and\
         (lons2d[i][j] < max_lon) and\
         (lats2d[i][j] > min_lat) and\
         (lats2d[i][j] < max_lat):
        if j < j_less:
          j_less = j
        if j > j_great:
          j_great = j

        if i < i_less:
          i_less = i
        if i > i_great:
          i_great = i

  # print('x,%d,%d y,%d,%d' % (j_less, j_great, i_less, i_great))
  return j_less, j_great, i_less, i_great

#########################################
#########################################
#########################################

def calculateLoc(queue, parameters):

  # print(parameters)
  queue_tickets = parameters[0]
  path_file     = parameters[1]
  file          = parameters[2]
  LocDict       = parameters[3]
  LocDictEmpty  = parameters[4]
  LATdeg_vec    = parameters[5]
  LONdeg_vec    = parameters[6]
  Ci            = int(parameters[7])
  Cj            = int(parameters[8])
  loc_res       = float(parameters[9])
  numproc       = int(parameters[10])

  # print("path_file: %s"%(path_file))
  # print("file: %s"%(file))
  # print("LocDictEmpty: %s"%(LocDictEmpty))
  # print("Ci: %d"%(Ci))
  # print("Cj: %d"%(Cj))
  # print("loc_res: %f"%(loc_res))

  Ct = Ci*Cj

  ##############################

  epoch = datetime.datetime.strptime('2000 01 00 00 00', '%Y %j %H %M %S')

  # file = abrir archivo
  fid = open(path_file + file, 'r')
  data = numpy.fromfile(fid, dtype='float32') # FR
  fid.close()

  IMG = []
  IMG = numpy.reshape(data, (Ci, Cj))

  ### Date

  year, doy, hh, mm, ss = getDate(file)

  time_data = str(year) + " " + str(doy) + " " + str(hh)  + " " + str(mm)  + " " + str(ss)
  date = datetime.datetime.strptime(time_data, '%Y %j %H %M %S')

  ite = float((date-epoch).total_seconds())/(24.0*60.0*60.0) # segundos desde el 2000-01-00:00:00 dividido total de secs en un dia

  cnt = 0

  # para cada loc calcular el recorte, el mean
  for idx,loc in enumerate(LocDict):

    # print(LocDict)

    loc_data = LocDict[loc]
    loc_lat = float(loc_data[0])
    loc_lon = float(loc_data[1])

    # print('getJILess')
    j_less, j_great, i_less, i_great = getJILess(loc_lat, loc_lon, loc_res, LATdeg_vec, LONdeg_vec)

    IMG_small = IMG[i_less:i_great,j_less:j_great]
    # print(IMG_small.shape)

    if IMG_small.shape == (0,0):
      # print("Error en %s"%(loc)) 
      mean = 0.0
    else:
      mean = numpy.mean(IMG_small)

    # print(numpy.size(IMG_small))

    if idx == 0:
      cnt = numpy.size(IMG_small)

    csza = cosSolarZenithAngle(loc_lat, loc_lon, date)

    if (mean>0) or (csza<=0):
      msk = 1
    else:
      msk = 0

    # Uso el array pasado como parametro para cargar los datos y encolar al final
    LocDictEmpty[loc] = LocType(mean, msk, cnt, ite)

    del IMG_small

  # for loc end

  # print(len(LocDictEmpty))

  date_value = DateType(year, doy, hh, mm, ss, ite)

  retorno = [date_value, LocDictEmpty]

  # encolar retorno
  queue.put(retorno)
  ticket = queue_tickets.get()

  if queue_tickets == numproc-1:
    queue_tickets.put("Fin de tickets")

  print("End makeLoc %d"%(ticket))

# calculateLoc()
