#!/usr/bin/python3
# -*- coding: utf-8 -*-

import numpy
import math
import glob
import calendar
from datetime import date, datetime
from loc_types import *

def getCsvLocs(file):

  name = numpy.genfromtxt(file, delimiter=' ', dtype=None, unpack=True, skip_header=3, usecols=(1,2,3))

  locs_dic       = dict()
  locs_dic_empty = dict()

  for val in name:
    key = str(val[0])[2:5]
    locs_dic[key]       = [float(val[1]), float(val[2])]
    locs_dic_empty[key] = []

  return locs_dic, locs_dic_empty

# getCsvCols

def doy(Y,M,D):
  """ given year, month, day return day of year
      Astronomical Algorithms, Jean Meeus, 2d ed, 1998, chap 7 """
  if calendar.isleap(Y):
      K = 1
  else:
      K = 2
  N = int((275 * M) / 9.0) - K * int((M + 9) / 12.0) + D - 30
  return N

# doy

def cantDias(Y):
  if calendar.isleap(Y):
    return 366
  else:
    return 365
# cantDias

def declinacionSolar(gamma):
  DELTArad = 0.006918 - 0.399912*math.cos(gamma) + 0.070257*math.sin(gamma) - 0.006758*math.cos(2*gamma) + 0.000907*math.sin(2*gamma) - 0.002697*math.cos(3*gamma) + 0.00148*math.sin(3*gamma);
  return float(DELTArad)
# declinacionSolar

# calculo ecuacion horaria (Es 0.000075, hay una errata en el coso de Gonzalo)
def ecuacionHoraria(gamma):
  c = 229.18;  # cte en min para la aprox de la ecuacion de tiempo 
  EcTmin = c*(0.000075 + 0.001868*math.cos(gamma) - 0.032077*math.sin(gamma) - 0.014615*math.cos(2*gamma) - 0.04089*math.sin(2*gamma));
  return float(EcTmin)
# ecuacionHoraria

# retorna el calculo del coseno del angulo zenital para la ubicacion, hora y fecha pasadas por parametro
# https://www.esrl.noaa.gov/gmd/grad/solcalc/azel.html
# AZ -34.918224, -56.16653
# 34°55'05.6"S 56°09'59.5"W
def cosSolarZenithAngle(phi, psi, datetime):
  # phi = lat <ubicacion>
  # psi = lon <ubicacion>
  # theta_s = solar zenith angle
  # delta = declination of the Sun
  # hora_solar
  # hora_local, con fraccion
  # omega = hour angle, in the local solar time.
  # cos(theta_s)= sen(phi)*sen(delta) + cos(phi)cos(delta)cos(omega)

  phi = math.radians(phi) # convierto phi a radianes
  pi  = math.pi

  Y = datetime.year
  M = datetime.month
  D = datetime.day
  h = float(datetime.hour)
  m = datetime.minute/60.0
  hora_local = h + m

  today_doy  = float(doy(Y,M,D))
  cant_dias  = float(cantDias(Y))
  gamma      = (2.0*pi*(today_doy-1.0))/cant_dias # calculo de gamma
  delta      = declinacionSolar(gamma)
  E          = ecuacionHoraria(gamma)
  hora_solar = hora_local + (psi+45.0)/15.0 + E/60.0 # psi en grados
  omega      = ((hora_solar-12.0)*pi)/12.0

  # print "Doy:%f, Dias:%f %f:%f %f gamma:%f delta:%f E:%f hora_solar:%f omega:%f" % (today_doy, cant_dias, h,m, hora_local, gamma, delta, E, hora_solar, omega)

  cz = math.sin(phi)*math.sin(delta) + math.cos(phi)*math.cos(delta)*math.cos(omega)
  if cz < 0:
    cz = 0

  return cz

# solarZenithAngle

def locValueArray2Array(locValueArray):

  new_array_mean = []
  new_array_msk  = []
  new_array_cnt  = []

  for item in locValueArray:
    new_array_mean.append(item.valor)
    new_array_msk.append(item.msk)
    new_array_cnt.append(item.cnt)

  return new_array_mean, new_array_msk, new_array_cnt
# locValueArray2Array

def locDateArray2Array(locDateArray):

  new_array_date = []

  for item in locDateArray:
    new_array_date.append(float(item.year))
    new_array_date.append(float(item.doy))
    new_array_date.append(float(item.hh))
    new_array_date.append(float(item.mm))
    new_array_date.append(float(item.ss))
    new_array_date.append(float(item.ite))

  return new_array_date
# locDateArray2Array
