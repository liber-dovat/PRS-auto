#!/usr/bin/python3.6
# -*- coding: utf-8 -*-

import os
import glob
import sys
import numpy
import time
from loc_types import *

from os.path         import isfile, basename
from multiprocessing import Process, Queue
from threading       import Lock
from makeLoc         import calculateLoc
from funciones       import locValueArray2Array, locDateArray2Array, getCsvLocs

#########################################
#########################################
#########################################

end_of_data = -1

if len(sys.argv) <= 1:
  print("Se nececitan los parámetros: path_base path_salida path_loc_file resolution start_year end_year")
  raise SystemExit()

path_base     = sys.argv[1]
path_salida   = sys.argv[2]
path_loc_file = sys.argv[3]
loc_res       = float(sys.argv[4])
start_year    = int(sys.argv[5])
end_year      = int(sys.argv[6])

mutex = Lock()

##################

# abro el archivo meta y guardo los datos
fid = open(path_base + 'meta/' + 'T000gri.META', 'r')
meta = numpy.fromfile(fid, dtype='float32')
fid.close()

# abro el archivo T000gri.LATvec y guardo los datos
fid = open(path_base + 'meta/' + 'T000gri.LATvec', 'r')
LATdeg_vec = numpy.fromfile(fid, dtype='float32')
LATdeg_vec = LATdeg_vec[::-1] # invierto el arreglo porque quedaba invertido verticalmente
fid.close()

# abro el archivo T000gri.LONvec y guardo los datos
fid = open(path_base + 'meta/' + 'T000gri.LONvec', 'r')
LONdeg_vec = numpy.fromfile(fid, dtype='float32')
fid.close()

Ci = int(meta[0])
Cj = int(meta[1])

##################

# cargar archivo de locs
locs_dic, locs_dic_empty = getCsvLocs(path_loc_file)

# si no existe, crar carpeta base (segun la resolucion) donde colocar los locs: T000loc_C01x01
resolution_basename = str(loc_res).replace('.', '') + "x" + str(loc_res).replace('.', '')
loc_prefix = "T000loc_C" + resolution_basename + "/"

path_salida_loc = path_salida + loc_prefix
os.makedirs(path_salida_loc, mode=0o775, exist_ok=True)

# Loop principal
for year in range(start_year, end_year+1):

  print("Año: " + str(year))

  locs_dic_acum = locs_dic_empty
  locs_date     = []
  files         = []

  path_file = path_base + 'B01-FR/' + str(year) + "/"

  files = sorted(glob.glob(path_file + "*.FR")) # for file in year
  files = list(map(basename,files))

  # files = files[0:12]

  while len(files) >= 1:

    print("Num files: %d" % (len(files)))

    processes     = []
    queue         = Queue()
    queue_tickets = Queue()

    # defino el total de procesos a lanzar por ves
    numproc = 30
    if len(files) < numproc:
      numproc = len(files)

    for ticket in range(0, numproc):
      queue_tickets.put(ticket)

    for m in range(0, numproc):
      mutex.acquire() # mutoexcluyo para hacer el pop sin coliciones
      file = files.pop()
      mutex.release() # libero el mutex

      # calculateLoc(queue, file, LocDict, LATdeg_vec, LONdeg_vec, Ci, Cj, loc_lat, loc_lon, loc_res)
      # array de datos de loc: coordenadas, resolucion
      # https://docs.python.org/2/library/multiprocessing.html
      parametros = [queue_tickets, path_file, file, locs_dic, locs_dic_acum, LATdeg_vec, LONdeg_vec, Ci, Cj, loc_res, numproc]

      # https://stackoverflow.com/questions/2046603/is-it-possible-to-run-function-in-a-subprocess-without-threading-or-writing-a-se

      p = Process(target=calculateLoc, args=(queue, parametros))
      processes.append(p)
      p.start()
    # for

    print("Num procesos: " + str(len(processes)))

    # queue ticket elememntos incializado en canidad de procs
    # mientas no esté vacía hago wait
    # cuando esté vacía consumo todos los elementos de la queus
    # while queue_tickets.qsize() != 0:
    while not queue_tickets.empty():
      time.sleep(0.5)
    print("Tickets empty")

    queue.close()
    queue_tickets.close()

    # https://stackoverflow.com/questions/32053618/how-to-to-terminate-process-using-pythons-multiprocessing
    for p in processes:
      p.join()
      # p.terminate()
      print("Join proc")
    # for
    print("End Join")

    # acumular resultados en el vector final

    # vacio la cola de datos
    while True:
      mutex.acquire() # mutoexcluyo para hacer el pop sin coliciones
      retorno = queue.get()
      mutex.release() # libero el mutex

      if retorno == "Fin de tickets":
        break

      date_result = retorno[0]
      dict_result = retorno[1]

      locs_date.append(date_result)
      print("date_result.ite:        %f"%(date_result.ite))

      for key in dict_result:
        # print(key)
        # print("dict_result[key].valor: %f"%(dict_result[key].valor))
        locs_dic_acum[key].append(dict_result[key])
      # for key
    # while not queue.empty

    print("len(locs_date): %d"%(len(locs_date)))

    del processes # vacío el array de procesos
    del queue
    del queue_tickets
  # end while

  # print("ACUMULADO:")
  for key in locs_dic_acum:
    # print(key)
    locs_dic_acum[key].sort()
    new_array_mean, new_array_msk, new_array_cnt = locValueArray2Array(locs_dic_acum[key])
    loc_dir = path_salida_loc + key + "/"

    # si no exixte crar directorio del loc
    os.makedirs(loc_dir, mode=0o775, exist_ok=True)

    file_base_name = key + "_" + resolution_basename + "_" + str(year)

    # guardar arreglos dentro de la carpeta del loc, para cada a~no
    output_file = open(loc_dir + file_base_name + '.FR', 'wb')
    myarray = numpy.array(new_array_mean, dtype=numpy.float32)
    myarray.tofile(output_file)
    output_file.close()

    output_file = open(loc_dir + file_base_name + '.MSK', 'wb')
    myarray = numpy.array(new_array_msk, dtype=numpy.int32)
    myarray.tofile(output_file)
    output_file.close()

    output_file = open(loc_dir + file_base_name + '.CNT', 'wb')
    myarray = numpy.array(new_array_cnt, dtype=numpy.int32)
    myarray.tofile(output_file)
    output_file.close()

  # for key end

  # guardar date por año, todos en la carpeta base de locs
  locs_date.sort()
  locs_date_array = locDateArray2Array(locs_date)
  date_base_name = "C" + resolution_basename + "_" + str(year)

  output_file = open(path_salida_loc + date_base_name + '.DATE', 'wb')
  myarray = numpy.array(locs_date_array, dtype=numpy.float32)
  myarray.tofile(output_file)
  output_file.close()
  print("guardando año " + str(year))

  del files
  del locs_dic_acum
  del locs_date

# end for year
