#!/bin/bash

time /sat/PRS/dev/loc/batchLoc.py /sat/art-sat/ART_G015x015UY_C015x015/ /sat/loc-sat/ /sat/loc-sat/meta/ZZ_estaciones_reducida 0.025 2001 2001
