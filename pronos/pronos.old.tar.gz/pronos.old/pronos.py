#!/usr/bin/python
# -*- coding: utf-8 -*-

import matplotlib
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy
import math
import datetime as dt
from matplotlib.dates import DayLocator, HourLocator, DateFormatter
import locale
locale.setlocale(locale.LC_ALL, '')

# http://stackoverflow.com/questions/20033396/how-to-visualize-95-confidence-interval-in-matplotlib
# http://stackoverflow.com/questions/27164114/show-confidence-limits-and-prediction-limits-in-scatter-plot
# http://matplotlib.org/1.2.1/examples/pylab_examples/errorbar_demo.html
# http://matplotlib.org/api/_as_gen/matplotlib.axes.Axes.errorbar.html

#########################################
#########################################
#########################################



def plotpronos(pronostico, desvio_up, desvio_down, medidas_reales, reales_up, reales_down, hora_pronos, pngPath, pngName, pathLogo):

  base = dt.datetime.now()

  # base = dt.datetime.now() - dt.timedelta(days=1)
  base = base.replace(hour=0)
  base = base.replace(minute=0)
  base = base.replace(second=0)
  base = base.replace(microsecond=0)

  horas = [float('nan')]*24

  for i in range(24):
    horas[i] = base + dt.timedelta(hours=i)

    # antes que hora_confianza (hora actual), ploteo dato real
    # sino ploteo pronostico
    # if i < hora_confianza:
    #   real[i] = i*7
    # elif i == hora_confianza:
    #   real[i] = i*8
    #   pronos[i] = i*8
    #   errores[i] = i*4
    # else:
    #   pronos[i] = i*8
    #   errores[i] = i*4

  # for i in horas:
  #   print i

  # for i in pronos:
  #   print i

  # for i in errores:
  #   print i

  #########################################

  hora_actual = 0

  for r in medidas_reales:
    if math.isnan(r):
      break
    else:
      hora_actual +=1
      print r

  hora_actual -= 1

  if hora_actual >= 0:
    pronostico[hora_actual]  = medidas_reales[hora_actual]
    desvio_up[hora_actual]   = reales_up[hora_actual]
    desvio_down[hora_actual] = reales_down[hora_actual]

  fig = plt.figure()
  ax  = fig.add_subplot(111)
  plt.xticks(fontsize=5)
  plt.yticks(fontsize=5)

  hours = HourLocator(byhour=range(24))

  ax.xaxis.set_major_locator(hours)
  ax.xaxis.set_major_formatter(DateFormatter("%H"))
  ax.tick_params(which='minor', labelsize=4.5)

  if hora_actual >= 0:
    ax.plot_date([horas[hora_actual], horas[hora_actual]], [0, 1400], 'k-', lw=0.5, zorder=110)
    ax.plot_date(horas[hora_actual], [-20], 'g^', markersize=4, markeredgewidth=0, alpha=0.8, zorder=115, clip_on=False)

    ax.plot_date(horas, medidas_reales, ls='-', marker="", linewidth=2, color='blue', zorder=100)
    ax.plot_date(horas, reales_up, ls='-', marker="", linewidth=1, color='#ff7619', alpha=0.5)
    ax.plot_date(horas, reales_down, ls='-', marker="", linewidth=1, color='#ff7619', alpha=0.5)
    ax.fill_between(horas, reales_up, reales_down, linewidth=0, facecolor='#ffb27e', alpha=0.3, zorder=-10)
  # if

  ax.plot_date(horas, pronostico, ls='-', marker="", linewidth=2, color='red', zorder=90)

  ax.plot_date(horas, desvio_up, ls='-', marker="", linewidth=1, color='red', alpha=0.5)
  ax.plot_date(horas, desvio_down, ls='-', marker="", linewidth=1, color='red', alpha=0.5)
  ax.fill_between(horas, desvio_up, desvio_down, linewidth=0, facecolor='red', alpha=0.2, zorder=-10)

  dia = dt.datetime.now()

  ax.set_title(u"Pronóstico de irradiación global en plano horizontal (GHI)", fontsize=8)
  ax.set_xlabel(u'Hora del día', fontsize=7)
  ax.set_ylabel(u'Irradiación horaria (Wh/m²)', fontsize=7)

  vmin = 0
  vmax = 1400

  ax.grid(True)
  ax.set_axisbelow(True)
  ax.set_ylim([vmin,vmax])

  # agrego el logo en el documento
  logo = plt.imread(pathLogo)
  plt.figimage(logo, 0, 10)

  plt.annotate("Generado el " + dia.strftime("%d/%m/%Y") + " " + hora_pronos, (0,0), (352,113), xycoords='axes fraction', textcoords='offset points', va='top', fontsize=6)

  # legend
  plt.annotate(u'Azul: irradiación real', (0,0), (20,-15), xycoords='axes fraction', textcoords='offset points', va='top', fontsize=5)
  plt.annotate(u'Rojo: Irradiación pronosticada', (0,0), (20,-21), xycoords='axes fraction', textcoords='offset points', va='top', fontsize=5)
  plt.annotate(u'Naranja: intervalo de confianza anterior', (0,0), (20,-28), xycoords='axes fraction', textcoords='offset points', va='top', fontsize=5)

  # guardo la imagen en la ruta destino
  fig.set_figheight(1.8)
  fig.set_figwidth(8)
  plt.savefig(pngPath + pngName, bbox_inches='tight', dpi=200) #, transparent=True
  plt.close() # cierro el archivo

# plotpronos

# [float('nan')]*24

fn = float('nan')

# medidas_reales = [-2.512792, # 00
#                   -2.397874, # 01
#                   -3.948804,
#                   -2.435107,
#                   -3.812512,
#                   -3.796653,
#                   -3.796883,
#                   -1.445206,
#                   53.435148,
#                   247.1874,
#                   537.27132,
#                   673.37624,
#                   734.22208,
#                   767.11232,
#                   219.77446,
#                   478.91652,
#                   458.59308,
#                   231.78268,
#                   36.669336,
#                   -4.89113,
#                   -4.264138,
#                   -4.426402,
#                   -3.960066,
#                   -4.641299
#                   ]

logo_path = "./logo_grafica_150.png"

desvio_up      = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,     289,558,528,301,106,0,0,0,0,0]
pronostico     = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,     219,478,458,231,36,-4,-4,-4,-3,-4]
desvio_down    = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,     149,408,388,161,-46,0,0,0,0,0]
reales_up      = [ 0, 0, 0, 0, 0, 0, 0, 0,113,307,597,743,794,837,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
medidas_reales = [ -2, -2, -3, -2, -3, -3, -3, -1, 53,247,537,673,734,767,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
reales_down    = [0,0,0,0,0,0,0,0,-23,177,447,603,664,697,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
plotpronos(pronostico, desvio_up, desvio_down, medidas_reales, reales_up, reales_down, "14:30", './png/', 'pronos.png', logo_path)

desvio_up      = [ 0, 0, 0, 0, 0, 0, 0, 0,113,307,597,743,794,837,289,558,528,301,106, 0, 0, 0, 0,0 ]
pronostico     = [  2, -2, -3, -2, -3, -3, -3, -1, 53,247,537,673,734,767,219,478,458,231, 36, -4, -4, -4, -3,-4 ]
desvio_down    = [0,0,0,0,0,0,0,0,-23,177,447,603,664,697, 79,338,318, 91,-46,0,0,0,0,0]
reales_up      = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
medidas_reales = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
reales_down    = [fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
plotpronos(pronostico, desvio_up, desvio_down, medidas_reales, reales_up, reales_down, "00:27", './png/', 'pronos_no_real.png', logo_path)

desvio_up      = [ fn, 0, 0, 0, 0, 0, 0, 0,113,307,597,743,794,837,289,558,528,301,106, 0, 0, 0, 0,0 ]
pronostico     = [ fn, -2, -3, -2, -3, -3, -3, -1, 53,247,537,673,734,767,219,478,458,231, 36, -4, -4, -4, -3,-4 ]
desvio_down    = [ fn,0,0,0,0,0,0,0,-23,177,447,603,664,697, 79,338,318, 91,-46,0,0,0,0,0]
reales_up      = [0,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
medidas_reales = [2,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
reales_down    = [0,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
plotpronos(pronostico, desvio_up, desvio_down, medidas_reales, reales_up, reales_down, "01:38", './png/', 'pronos_1_real.png', logo_path)

desvio_up      = [ fn, fn, 0, 0, 0, 0, 0, 0,113,307,597,743,794,837,289,558,528,301,106, 0, 0, 0, 0, 0]
pronostico     = [ fn, fn, -3, -2, -3, -3, -3, -1, 53,247,537,673,734,767,219,478,458,231, 36, -4, -4, -4, -3,-4 ]
desvio_down    = [ fn, fn, 0, 0,0,0,0,0,-23,177,447,603,664,697, 79,338,318, 91,-46,0,0,0,0,0]
reales_up      = [0,0,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
medidas_reales = [2,2,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
reales_down    = [0,0,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn,fn]
plotpronos(pronostico, desvio_up, desvio_down, medidas_reales, reales_up, reales_down, "02:15", './png/', 'pronos_2_real.png', logo_path)